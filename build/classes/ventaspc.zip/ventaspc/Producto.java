/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ventaspc;
import java.util.Scanner;
/**
 *
 * @author Ivan
 */
public abstract class Producto implements Computable{
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    /*private int disponibilidad;
    public Producto(){
        disponibilidad = 10;
    }*/
    public Producto(String marca, String modelo, String color, double precio){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }
    //Gets
    public String getMarca(){
        return this.marca;
    }
    public String getModelo(){
        return this.modelo;
    }
    public String getColor(){
        return this.color;
    }
    public double getPrecio(){
        return this.precio;
    }
    public void setProducto(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa la marca: ");
        this.marca = sc.nextLine();
        System.out.print("Ingresa el modelo: ");
        this.modelo = sc.nextLine();
        System.out.print("Ingresa el color: ");
        this.color = sc.nextLine();
        System.out.print("Ingresa el precio: ");
        this.precio = sc.nextDouble();
        sc.nextLine();
    }
   // @Override
    //public int getDisponibilidad(){
    //    return this.disponibilidad;
    //}
    /*@Override
    public void disponibilidadDecremento(){
        disponibilidad--;
    }*/
    public abstract String getProcesador();
    public abstract int getRam();
    public abstract int getHdd();
    public abstract String getTarjetaVideo();
    public abstract String getTarjetaAudio();
}

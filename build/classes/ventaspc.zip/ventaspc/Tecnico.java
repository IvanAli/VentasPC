/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ventaspc;

/**
 *
 * @author Ivan
 */
public class Tecnico extends Empleado{
    private double comision;
    public Tecnico(String nombre, String apellido, double salario){
        super(nombre, apellido, salario);
        //this.comision = comision;
    }
    
    public void reparar(){
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ventaspc;
import java.util.Scanner;
/**
 *
 * @author Ivan
 */
public class VentasPC {
    public int opc;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in);
         int op=0;
         String name;
         int tmp1;
         int tmp2;
         int compra;
         int While=1;
         int a=0;
        
         Empresa PCSell = new Empresa();
         PCSell.products();
        do { 
            System.out.println("-----------------------------------");
            op=0;
        System.out.println("1. Crear un nuevo cliente");
        System.out.println("2. Mostrar computadoras a la venta");
        System.out.println("3. Registro de compra de computadora (Nota: el cliente tiene que haberse dado de alta");
        System.out.println("4. Registro de nuevas computadoras que han llegado a la empresa\n5. Salir del programa");
        System.out.print("Ingresa el numero de la opcion: ");
        op = sc.nextInt();
        switch (op){
        //Case 1
           case 1:
                PCSell.datosCliente();
                PCSell.incrementoContador();
           break;
            //Case 2
           case 2:
                PCSell.printProducts();
           break;
            //Case 3
           case 3:
                tmp1 = 0;
                sc.nextLine();
                //System.out.println("Metodo cliente: " + PCSell.getClienteNombre());
                System.out.print("Escribe tu nombre: ");
                name = sc.nextLine();
                for (int i=0; i<PCSell.getNumClientes(); i++){
                    if (name.equals(PCSell.clientes.get(i).getNombre())){
                        tmp1 = 1;
                        System.out.print("Se ha encontrado a " + name + ". Cedula: " + PCSell.clientes.get(i).getCedula());
                        System.out.println(" -- Cliente #" + (i+1));
                        System.out.println("Productos disponibles: ");
                        for (Computable c : PCSell.productos){
                            if (PCSell.productos[tmp1-1] != null){ //Nota propia: Revisar la condicion
                            System.out.print(tmp1 + ". ");
                            System.out.println(c.getMarca() + " | " + c.getModelo() + " | " + "$" + c.getPrecio() + " USD");
                            tmp1++;
                            }
                        }
                        System.out.print("Cual desea comprar? (Numero): ");
                        compra = sc.nextInt();
                        sc.nextLine();
                        
                        //Compra de la PC / ingreso para empresa
                        PCSell.clientes.get(i).comprar(PCSell.productos, PCSell, compra-1);
                        System.out.println("Compra registrada!");
                        System.out.print("Precio de la compra hecha: " + PCSell.productos[compra-1].getPrecio());
                        System.out.println(". Ingreso acumulado de la empresa: " + PCSell.getIngreso());
                    }
                }
                if (tmp1 == 0){
                    System.out.println("No se ha encontrado a " + name + " como cliente");
                }
                tmp1 = 0;
           break;
           case 4:
               int tamProductos=0;
               for (int i=0; i<PCSell.productos.length; i++){
                   if (PCSell.productos[i] == null){
                       tamProductos = i;
                       break;
                   }
               }
               System.out.println("La empresa solo puede disponer de 10 productos. Por el momento hay " + tamProductos + " computadoras");
               if (tamProductos < 10){
                    PCSell.nuevoProducto(PCSell.productos, PCSell, tamProductos);
                    System.out.println("Marca: " + PCSell.productos[3].getMarca());
                    System.out.println("Tam: " + tamProductos);
                    //System.out.println("Procesador: " + PCSell.productos[3].getProcesador());
               }
           break;
           case 5:
               While=0;
               System.exit(0);
           break;
           default:
               System.out.println("La opcion no se reconoce. Intente de nuevo.");
        }
            
        } 
        while (While==1);
        
       
        
        
        
    }
    
}

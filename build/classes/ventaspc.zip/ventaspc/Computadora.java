/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ventaspc;
import java.util.Scanner;
/**
 *
 * @author Ivan
 */
public class Computadora extends Producto{
    private String procesador;
    private int ram;
    private int hdd;
    private String tarjetaVideo;
    private String tarjetaAudio;
    
    public Computadora(String marca, String modelo, String color, double precio, String procesador, int ram, int hdd, String tarjetaVideo, String tarjetaAudio){
        super(marca, modelo, color, precio);
        this.procesador = procesador;
        this.ram = ram;
        this.hdd = hdd;
        this.tarjetaVideo = tarjetaVideo;
        this.tarjetaAudio = tarjetaAudio;
    }
    @Override
    public String getMarca() {
        return super.getMarca(); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public String getModelo() {
        return super.getModelo(); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public String getColor() {
        return super.getColor(); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public double getPrecio() {
        return super.getPrecio(); //To change body of generated methods, choose Tools | Templates.
    }
    //@Override
    //public int getDisponibilidad(){
    //    return super.getDisponibilidad();
    //}
    /*@Override
    public void disponibilidadDecremento(){
        return super.disponibilidadDecremento();
    }*/
    public String getProcesador(){
        return this.procesador;
    }
    public int getRam(){
        return this.ram;
    }
    public int getHdd(){
        return this.hdd;
    }
    public String getTarjetaVideo(){
        return this.tarjetaVideo;
    }
    public String getTarjetaAudio(){
        return this.tarjetaAudio;
    }
    @Override
    public void setProducto(){
        super.setProducto();
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa el procesador: ");
        this.procesador = sc.nextLine();
        System.out.print("Ingresa la cantidad de memoria RAM: ");
        this.ram = sc.nextInt();
        sc.nextLine();
        System.out.print("Ingresa la capacidad del HDD: ");
        this.hdd = sc.nextInt();
        sc.nextLine();
        System.out.print("Ingresa el nombre de la tarjeta de video: ");
        this.tarjetaVideo = sc.nextLine();
        System.out.print("Ingresa el nombre de la tarjeta de audio: ");
        this.tarjetaAudio = sc.nextLine();
    }
}

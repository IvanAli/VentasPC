/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ventaspc;
import java.util.Scanner;
/**
 *
 * @author Ivan
 */
public class Cliente {
    public String nombre;
    private String apellido;
    private int cedula;
    private String direccion;
    private String ciudad;
    private String telefono;
    private int compras;
    Scanner scan = new Scanner(System.in);
    
   /* public Cliente(String nombre, String apellido, int cedula, String direccion, String ciudad, String telefono){
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.telefono = telefono;
        
    }*/
    public Cliente(){
        compras = 0;
        //setClienteInfo();
       /* System.out.println("Nombre: ");
        nombre = sc.nextLine();
        System.out.println("Apellido: ");
        apellido = sc.nextLine();
        System.out.println("Cedula: ");
        cedula = sc.nextInt();
        sc.nextLine();
        System.out.println("Direccion: ");
        direccion = sc.nextLine();
        System.out.println("Ciudad: ");
        ciudad = sc.nextLine();
        System.out.println("Telefono: ");
        telefono = sc.nextLine();*/
        
    }
    public void setClienteInfo(){
        
        System.out.println("Nombre: ");
        this.nombre = scan.nextLine();
        System.out.println("Apellido: ");
        this.apellido = scan.nextLine();
        System.out.println("NUMERO de Cedula: ");
        this.cedula = scan.nextInt();
        scan.nextLine();
        System.out.println("Direccion: ");
        this.direccion = scan.nextLine();
        System.out.println("Ciudad: ");
        this.ciudad = scan.nextLine();
        System.out.println("Telefono: ");
        this.telefono = scan.nextLine();
        
    
    }
    /*public void comprar(double cantidad){
        Empresa.setIngreso(cantidad);
    }*/
    public void comprar(Producto[] pc, Empresa emp, int i){
        emp.setIngreso(pc[i].getPrecio());
        //compras++;
    }
    /*public void comprasIncremento(){
        compras++;
    }*/
    public String getNombre(){
        return this.nombre;
    }
    public int getCedula(){
        return this.cedula;
    }
}

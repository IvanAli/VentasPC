/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ventaspc;
import java.util.ArrayList;
/**
 *
 * @author Ivan
 */
public class Empresa {
    private Empleado empleados;
    protected Producto[] productos = new Computadora[10];
    protected ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    private int numVentas;
    private int numClientes;
    private double ingreso;
    //private Cliente[] clientes = new Cliente[1];
    private int contadorClientes; //contadorEmpleados esta vez
    public Empresa(){
        contadorClientes=0;
        numVentas = 0;
        numClientes = clientes.size();
        ingreso = 0;
        products();
    }
    public void setIngreso(double ingresoCliente){
        ingreso += ingresoCliente;
    }
    public void datosCliente(){
        clientes.add(new Cliente());
        clientes.get(contadorClientes).setClienteInfo();
        //Los siguientes comentarios son código no utilizado
        //System.out.println(clientes.get(contadorClientes).getNombre()); <-- Prueba de contador unicamente, no tiene importancia
        //System.out.println("Contador clientes:" + contadorClientes);
        ////contadorClientes++;
        
        //System.out.println("Cliente: " + clientes[contadorClientes].getNombre() + ". Cedula: " + clientes[contadorClientes].getCedula());
    }
    public String getClienteNombre(){
        return clientes.get(0).getNombre();
    }
    public void products(){
        //Producto[] productos = {
            productos[0] = new Computadora("DELL","Inspiron","Silver",629,"Intel Core i5",8,1000,"Intel HD Graphics","Waves MaxxAudio");
            productos[1] = new Computadora("Lenovo","Ideapad","Silver",459,"Intel Core i5",4,500,"Intel HD Graphics","Waves MaxxAudio");
            productos[2] = new Computadora("DELL","XPS","Black",1999,"Intel Core i7",16,1000,"nVIDIA GeForce 8500","Creative Sound Blaster Z");
        //};
        /*for (int i=0; i<productos.length; i++){
            //Producto[] productos = new Producto[2];
            //productos[i] = new Computadora("DELL","Inspiron","Silver",629,"Intel Core i5",8,1,"Intel HD Graphics","Waves MaxxAudio");
            System.out.println(productos[i].getMarca() + productos[i].getModelo() + productos[i].getColor() + productos[i].getPrecio());
        }*/
        
    }
    public void printProducts(){
        int i=0;
        for (Computable c : productos){
            if (productos[i] != null){
            System.out.println("Marca: " + c.getMarca() + " | Modelo: " + c.getModelo() + " | Color: " + c.getColor() + 
                    " | Precio: $" + c.getPrecio() + " | Procesador: " + c.getProcesador() + 
                    " | Memoria RAM: " + c.getRam() + "GB. | HDD: " + c.getHdd() + "GB | Tarjeta de Video: " + c.getTarjetaVideo() + 
                    " | Tarjeta de Audio: " + c.getTarjetaAudio());
            System.out.println("-----------------------------------");
            i++;
        }
        }
    }
    public void nuevoProducto(Producto pc[], Empresa emp, int tam){
        
               emp.productos[tam] = new Computadora("0","0","0",0,"0",0,0,"0","0");
               //emp.pc{no].setProducto();
               productos[tam].setProducto();
    }
    //public void nuevoCliente(){
        //clientes.add(new Cliente());
        //clientes[contadorClientes] = new Cliente();
        //System.out.println(clientes[contadorClientes].getNombre());
        /*Cliente[] clientes = {
            new Cliente()
        };*/
        //clientes.setClienteInfo();
        //incrementoContador();
   // }
    
    /*public Empresa(String nombre, String apellido, double salario){
        
        trabajador[0] = new Empleado();
    }*/
    /*public void nuevoCliente(){
        trabajador[contadorClientes] = new Empleado();
        incrementoContador();
    }*/
    public void incrementoContador(){
        contadorClientes++;
        System.out.println("Contador incrementado:" + contadorClientes);
    }
    public int getNumClientes(){
        return clientes.size();
    }
    public double getIngreso(){
        return ingreso;
    }
    
}
